import networkx as nx
import numpy as np
import scipy.sparse as sp
import torch
from itertools import combinations
from caculateParameters11 import caculate_YxYf



def k_hop_neighbors(graph, node, k):
    neighbors = set()
    current_level_nodes = {node}

    for _ in range(k):
        next_level_nodes = set()
        for n in current_level_nodes:
            next_level_nodes.update(graph.neighbors(n))
        neighbors.update(next_level_nodes)
        current_level_nodes = next_level_nodes

    neighbors.discard(node)
    return neighbors


def jaccard_similarity(set1, set2):
    intersection = len(set1.intersection(set2))
    union = len(set1.union(set2))
    return intersection / union if union > 0 else 0


# def node_features_similarity(features1, features2):
#     # 假设 features1 和 features2 是 csr_matrix
#     features1_dense = features1.toarray().flatten()  # 转换为稠密数组并展平
#     features2_dense = features2.toarray().flatten()  # 转换为稠密数组并展平
#
#     return jaccard_similarity(set(features1_dense), set(features2_dense))

def node_features_similarity(features1, features2):
    a = features1.toarray().flatten()  # 转换为稠密数组并展平
    b = features2.toarray().flatten()  # 转换为稠密数组并展平

    # # 检查形状
    # if a.shape != b.shape:
    #     raise ValueError(f"Dimension mismatch: {a.shape} vs {b.shape}")
    #
    # intersection = np.count_nonzero(a * b)
    # J = intersection * 1.0 / (np.count_nonzero(a) + np.count_nonzero(b) - intersection)

    inner_product = (a * b).sum()
    J = inner_product / (np.sqrt(np.square(a).sum()) * np.sqrt(np.square(b).sum()) + 1e-8)

    return J


def k_hop_similarity(graph, node1, node2, k, neighbor_cache, features):
    if graph.has_edge(node1, node2):
        if (node1, k) not in neighbor_cache:
            neighbor_cache[(node1, k)] = k_hop_neighbors(graph, node1, k)
        if (node2, k) not in neighbor_cache:
            neighbor_cache[(node2, k)] = k_hop_neighbors(graph, node2, k)

        neighbors1 = neighbor_cache[(node1, k)]
        neighbors2 = neighbor_cache[(node2, k)]
        # jaccard_similarity cosine_similarity
        neighbor_similarity = jaccard_similarity(neighbors1, neighbors2)
        feature_similarity = node_features_similarity(features[node1], features[node2])
        weight_neighbors = 0.1
        weight_features = 0.9
        # weight_neighbors = 0.6 weight_features = 0.4
        final_similarity = (weight_neighbors * neighbor_similarity + weight_features * feature_similarity)
        # 0.6431      0.6446
        # Combine the two similarities (you can adjust the weighting as needed)
        # 最高 0.2 0.8 30
        return final_similarity
    return None



def Caculate(A, features):
    G = nx.from_numpy_array(A, create_using=nx.DiGraph())
    k = 2
    similarity_matrix = {}
    neighbor_cache = {}

    for node1, node2 in combinations(G.nodes, 2):
        similarity = k_hop_similarity(G, node1, node2, k, neighbor_cache, features)
        if similarity is not None:
            similarity_matrix[(node1, node2)] = similarity

    return similarity_matrix



def RobustModel(A, features, ptbrate):

    similarity_matrix = Caculate(A, features)
    best_A = A.copy()


    # Feff_tmp, Xeff_tmp, Yx_tmp, Yf_tmp, Y1_tmp, Y2_tmp = 0, 0, 0, 0, 0,
    Y1_node1, Y1_node1_tmp, Y2_node1, Y2_node1_tmp, Y1_node2, Y1_node2_tmp, Y2_node2, Y2_node2_tmp = 0, 0, 0, 0, 0 , 0, 0, 0
    initial_similarity_count = len(similarity_matrix)


    for iteration in range(100000000):


        min_similarity_edge = min(similarity_matrix.items(), key=lambda item: item[1])
        node1, node2 = min_similarity_edge[0]
        del similarity_matrix[min_similarity_edge[0]]

        tmp_A = best_A.copy()

        if tmp_A[node1, node2]==1 and tmp_A[node2, node1]==1:
            tmp_A[node1, node2] = 0
            tmp_A[node2, node1] = 0

        Y1_node1, Y2_node1, Y1_node2, Y2_node2 = caculate_YxYf(tmp_A, features, node1, node2)

        # if iteration % 1000 == 0:
        #     # print("Iteration:", iteration, "Y1_node1:", Y1_node1, "Y2_node1:", Y2_node1, "Y1_node2:", Y1_node2, "Y2_node2:", Y2_node2)
        #     print("Xeff:", Xeff)

        if Y1_node1 > Y1_node1_tmp or Y2_node1 > Y2_node1_tmp or Y1_node2 > Y1_node2_tmp or Y2_node2 > Y2_node2_tmp:
        # if Y1_node1 > Y1_node1_tmp or Y2_node1 > Y2_node1_tmp or Y1_node2 > Y1_node2_tmp and Y2_node2 > Y2_node2_tmp:
        # if Y1_node1 > Y1_node1_tmp and Y1_node2 > Y1_node2_tmp:
        #     count  = count + 1
        #     print("count: ", count)
            Y1_node1_tmp = Y1_node1
            Y2_node1_tmp = Y2_node1

            Y1_node2_tmp = Y1_node2
            Y2_node2_tmp = Y2_node2

            best_A = tmp_A
            # print("iteration:", iteration)
        else:
            tmp_A[node1, node2] = 1
            tmp_A[node2, node1] = 1


        current_similarity_count = len(similarity_matrix)
        if current_similarity_count <= initial_similarity_count * 0.99:
            break
    # Yx, Yf = caculate_YxYf2(A, features)
    # print("Yx:", Yx, "Yf:", Yf)
    # sparse_matrix = sp.csr_matrix(best_A)
    # sp.save_npz(f'/home/chenwenxiong/project/defense/tmp{n}/{dataset}_{attack}_adj_{ptbrate}_2.npz', sparse_matrix)
    # sp.save_npz(f'/home/chenwenxiong/project/defense/noFeature2/tmp{n}/{dataset}_{attack}_adj_{ptbrate}.npz', sparse_matrix)
    # best_A = truncatedSVD(best_A,k=100)
    return best_A

# def truncatedSVD(data, k=100):
#     """Truncated SVD on input data.
#
#     Parameters
#     ----------
#     data :
#         input matrix to be decomposed
#     k : int
#         number of singular values and vectors to compute.
#
#     Returns
#     -------
#     numpy.array
#         reconstructed matrix.
#     """
#     print('=== GCN-SVD: rank={} ==='.format(k))
#     if sp.issparse(data):
#         data = data.asfptype()
#         U, S, V = sp.linalg.svds(data, k=k)
#         print("rank_after = {}".format(len(S.nonzero()[0])))
#         diag_S = np.diag(S)
#     else:
#         U, S, V = np.linalg.svd(data)
#         U = U[:, :k]
#         S = S[:k]
#         V = V[:k, :]
#         print("rank_before = {}".format(len(S.nonzero()[0])))
#         diag_S = np.diag(S)
#         print("rank_after = {}".format(len(diag_S.nonzero()[0])))
#
#     return U @ diag_S @ V