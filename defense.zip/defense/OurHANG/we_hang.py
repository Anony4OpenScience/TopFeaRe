import torch.optim as optim
from deeprobust.graph.utils import *
from defense.load_datasets.dataset2 import Dataset
from defense.load_datasets.attacked_data2 import PrePtbDataset
import argparse
import os
import random
from defense.precode.graphode.GNN_main import GNN_main
from torch_geometric.utils import dense_to_sparse
from tqdm import trange
from TopFeaRe.method_detail import RobustModel


torch.cuda.empty_cache()

def set_seed(seed=2022):
    random.seed(seed)
    np.random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True


def test_model(model,data):
    model.eval()
    accs = []
    with torch.no_grad():
        logits = model(data.features,data.adj).half()
        for mask in [data.train_mask, data.val_mask, data.test_mask]:
            pred = logits[mask].max(1)[1]
            acc = pred.eq(data.labels[mask]).sum().item() / mask.sum().item()
            accs.append(acc)
    return  accs



def test_defend(args,data):
    features = data.features
    labels = data.labels
    adj = data.adj

    opt = vars(args)
    opt['num_classes'] = labels.max().item() + 1
    model = GNN_main(opt, features.shape[1], args.device)
    model = model.to(args.device)
    optimizer = optim.Adam(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    lf = torch.nn.CrossEntropyLoss()
    best_time = val_acc = test_acc = train_acc = best_epoch = 0
    counter = 0
    # add tqdm
    epoch_bar = trange(args.epochs,ncols=100)
    for i in epoch_bar:
        model.train()
        optimizer.zero_grad()
        out = model(features, adj).half()
        loss = lf(out[data.train_mask], data.labels.squeeze()[data.train_mask])
        loss.backward()
        optimizer.step()
        # set tqdm description

        # print("Epoch: {:03d}, Train loss: {:.4f}".format(i, loss.item()))
        tmp_train_acc, tmp_val_acc, tmp_test_acc = test_model(model, data)
        if tmp_val_acc > val_acc:
            val_acc = tmp_val_acc
            test_acc = tmp_test_acc
            train_acc = tmp_train_acc
            best_epoch = i
            counter = 0
        else:
            counter += 1
        # print("Epoch: {:03d}, Train: {:.4f}, Val: {:.4f}, Test: {:.4f}".format(i, tmp_train_acc, tmp_val_acc, tmp_test_acc))
        epoch_bar.set_description("Epoch: {:03d}, loss: {:.4f},Train: {:.4f}, Val: {:.4f}, Test: {:.4f}".format(i, loss.item(),tmp_train_acc, tmp_val_acc, tmp_test_acc))
        if counter == args.patience:
            print("Early Stopping")
            break

    print("Best Epoch: {:03d}, Train: {:.4f}, Val: {:.4f}, Test: {:.4f}".format(best_epoch, train_acc, val_acc, test_acc))
    return train_acc, val_acc, test_acc


def main(n, attack, args):
    args.device = torch.device('cuda', args.gpu)
    set_seed(args.seed)

    # 加载数据集
    data = Dataset(root=f'/root/', name=args.dataset, setting='prognn')
    adj, features, labels = data.adj, data.features, data.labels

    idx_train, idx_val, idx_test = data.idx_train, data.idx_val, data.idx_test
    print("训练集节点数: ", len(idx_train))
    print("验证集节点数: ", len(idx_val))
    print("测试集节点数: ", len(idx_test))

    # 预处理邻接矩阵、特征和标签
    adj, features, labels = preprocess(adj, features, labels, preprocess_adj=False)

    # 加载被扰动的数据
    perturbed_data = PrePtbDataset(root=f'/root/',
                                   name=args.dataset,
                                   attack_method=attack,
                                   ptb_rate=args.ptb_rate)

    perturbed_adj = perturbed_data.adj


    if attack == 'nifa' or attack == 'tdgia':
        features = perturbed_data.feature  # 可能是稀疏矩阵

    '结合'
    perturbed_adj = perturbed_adj.toarray()
    perturbed_adj = RobustModel(perturbed_adj, features, args.ptb_rate)

    perturbed_adj = sp.csr_matrix(perturbed_adj)

    modified_adj = perturbed_adj.todense()
    print(f"扰动邻接矩阵形状: {modified_adj.shape}")

    # 使用Dataset的adj形状作为基准，确保一致性
    num_nodes = adj.shape[0]  # 基于原始adj的节点数（例如1222）
    print(f"裁剪后的节点数: {num_nodes}")

    # 裁剪modified_adj以匹配Dataset的节点数
    if modified_adj.shape[0] != num_nodes:
        modified_adj = modified_adj[:num_nodes, :num_nodes]
        print(f"调整扰动邻接矩阵到: {modified_adj.shape}")

    modified_adj = torch.from_numpy(modified_adj).float().to(args.device)

    target_nodes = perturbed_data.target_nodes
    if attack == 'nifa':
        idx_test = target_nodes

    # 将features转换为PyTorch张量
    import scipy.sparse
    if scipy.sparse.issparse(features):
        features = torch.from_numpy(features.toarray()).float()
    elif isinstance(features, np.ndarray):
        features = torch.from_numpy(features).float()

    # 处理labels，确保它是1维整数标签
    if isinstance(labels, np.ndarray):
        if labels.ndim > 1:  # 如果是2维（例如one-hot），转为1维
            labels = np.argmax(labels, axis=1)
        labels = torch.from_numpy(labels).long()
    elif isinstance(labels, torch.Tensor):
        if labels.dim() > 1:  # 如果是2维张量，转为1维
            labels = torch.argmax(labels, dim=1)
        labels = labels.long()
    else:
        raise TypeError(f"Unsupported type for labels: {type(labels)}")

    # 裁剪features和labels以匹配num_nodes
    if features.shape[0] != num_nodes:
        features = features[:num_nodes]
    if labels.shape[0] != num_nodes:
        labels = labels[:num_nodes]

    # 将数据移动到设备（GPU）
    data.features = features.to(args.device)
    data.labels = labels.to(args.device)

    if args.defence in ['gcn']:
        data.adj = adj.to(args.device)
    else:
        adj_csr = dense_to_sparse(adj)
        data.adj = adj_csr

    # 创建掩码，确保长度与裁剪后的节点数一致
    train_mask = torch.zeros(num_nodes, dtype=torch.bool)
    train_mask[idx_train] = 1
    data.train_mask = train_mask.to(args.device)

    val_mask = torch.zeros(num_nodes, dtype=torch.bool)
    val_mask[idx_val] = 1
    data.val_mask = val_mask.to(args.device)

    test_mask = torch.zeros(num_nodes, dtype=torch.bool)
    test_mask[idx_test] = 1
    data.test_mask = test_mask.to(args.device)

    if args.defence in ['gcn']:
        data.adj = modified_adj.to(args.device)
    else:
        adj_mod_csr = dense_to_sparse(modified_adj)
        data.adj = adj_mod_csr

    print("测试被扰动的数据")
    _, _, test_acc_adv = test_defend(args, data)

    return test_acc_adv







#1:0.8067, 2:0.7730, 3:0.8272, 4:0.8354, 5:0.7894, 6:0.8149, 7:0.8231, 8:0.8241, 9:0.8190, 10:0.8078


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--no-cuda', action='store_true', default=False,
                        help='Disables CUDA training.')
    parser.add_argument('--seed', type=int, default=123, help='Random seed.')
    parser.add_argument('--epochs', type=int, default=200,
                        help='Number of epochs to train.')
    parser.add_argument('--lr', type=float, default=0.01,
                        help='Initial learning rate.')
    parser.add_argument('--weight_decay', type=float, default=5e-4,
                        help='Weight decay (L2 loss on parameters).')
    parser.add_argument('--hidden', type=int, default=64,
                        help='Number of hidden units.')
    parser.add_argument('--layers', type=int, default=4,
                        help='Number of hidden layers.')
    parser.add_argument('--dropout', type=float, default=0.5,
                        help='Dropout rate (1 - keep probability).')
    parser.add_argument('--dataset', type=str, default='cora_ml', choices=['aifb','email','cora', 'cora_ml', 'citeseer', 'polblogs', 'pubmed'], help='dataset')
    parser.add_argument('--ptb_rate', type=float, default=0.05,  help='pertubation rate')
    parser.add_argument('--model', type=str, default='Meta-Self',
            choices=['Meta-Self', 'A-Meta-Self', 'Meta-Train', 'A-Meta-Train'], help='model variant')

    parser.add_argument('--defence', type=str, default='hamgcnv5', help='model variant')
    parser.add_argument('--gpu', type=int, default=0, help='gpu.')
    parser.add_argument('--patience', type=int, default=100, help='patience.')
    parser.add_argument('--runtime', type=int, default=3, help='runtime.')
    parser.add_argument('--time_ode', type=int, default=3, help='runtime.')

    ###### args for pde model ###################################

    parser.add_argument('--hidden_dim', type=int, default=256, help='Hidden dimension.')
    parser.add_argument('--proj_dim', type=int, default=256, help='proj_dim dimension.')
    parser.add_argument('--fc_out', dest='fc_out', action='store_true',
                        help='Add a fully connected layer to the decoder.')
    parser.add_argument('--input_dropout', type=float, default=0.0, help='Input dropout rate.')
    # parser.add_argument('--dropout', type=float, default=0.0, help='Dropout rate.')
    parser.add_argument("--batch_norm", dest='batch_norm', action='store_true', help='search over reg params')
    parser.add_argument('--optimizer', type=str, default='adam', help='One from sgd, rmsprop, adam, adagrad, adamax.')
    # parser.add_argument('--lr', type=float, default=0.005, help='Learning rate.')
    parser.add_argument('--decay', type=float, default=5e-4, help='Weight decay for optimization')
    parser.add_argument('--epoch', type=int, default=100, help='Number of training epochs per iteration.')
    parser.add_argument('--alpha', type=float, default=1.0, help='Factor in front matrix A.')
    parser.add_argument('--alpha_dim', type=str, default='sc', help='choose either scalar (sc) or vector (vc) alpha')
    parser.add_argument('--no_alpha_sigmoid', dest='no_alpha_sigmoid', action='store_true',
                        help='apply sigmoid before multiplying by alpha')
    parser.add_argument('--beta_dim', type=str, default='sc', help='choose either scalar (sc) or vector (vc) beta')
    parser.add_argument('--block', type=str, default='constantfrac', help='constantfrac')
    parser.add_argument('--function', type=str, default='transgrand', help='transgrand, transformer, belgrand')
    parser.add_argument('--use_mlp', dest='use_mlp', action='store_true',
                        help='Add a fully connected layer to the encoder.')
    parser.add_argument('--add_source', dest='add_source', action='store_true',
                        help='If try get rid of alpha param and the beta*x0 source term')

    # ODE args
    parser.add_argument('--time', type=float, default=3.0, help='End time of ODE integrator.')
    parser.add_argument('--method', type=str, default='predictor',
                        help="set the numerical solver: dopri5, euler, rk4, midpoint")
    parser.add_argument('--step_size', type=float, default=1.0,
                        help='fixed step size when using fixed step solvers e.g. rk4')
    parser.add_argument('--ode_blocks', type=int, default=1, help='number of ode blocks to run')
    parser.add_argument("--no_early", action="store_true",
                        help="Whether or not to use early stopping of the ODE integrator when testing.")

    # Attention args
    parser.add_argument('--leaky_relu_slope', type=float, default=0.2,
                        help='slope of the negative part of the leaky relu used in attention')
    parser.add_argument('--attention_dropout', type=float, default=0., help='dropout of attention weights')
    parser.add_argument('--heads', type=int, default=4, help='number of attention heads')
    parser.add_argument('--attention_norm_idx', type=int, default=0, help='0 = normalise rows, 1 = normalise cols')
    parser.add_argument('--attention_dim', type=int, default=16,
                        help='the size to project x to before calculating att scores')
    parser.add_argument('--mix_features', dest='mix_features', action='store_true',
                        help='apply a feature transformation xW to the ODE')
    parser.add_argument('--reweight_attention', dest='reweight_attention', action='store_true',
                        help="multiply attention scores by edge weights before softmax")
    parser.add_argument('--attention_type', type=str, default="scaled_dot",
                        help="scaled_dot,cosine_sim,pearson, exp_kernel")
    parser.add_argument('--square_plus', action='store_true', help='replace softmax with square plus')

    parser.add_argument('--data_norm', type=str, default='gcn',
                        help='rw for random walk, gcn for symmetric gcn norm')
    parser.add_argument('--self_loop_weight', type=float, default=1.0, help='Weight of self-loops.')
    parser.add_argument('--alpha_ode', type=float, default=0.5, help='alpha_ode')
    parser.add_argument('--weightax', type=float, default=1.0, help='alpha_ode')
    parser.add_argument('--no_alpha', dest='no_alpha', action='store_true',
                        help='apply sigmoid before multiplying by alpha')

    # parser.add_argument('--ptb_rate', type=float, default=0.05, help='pertubation rate')

    'cora_ml', 'cora', 'citeseer', 'pubmed'
    'meta, pgd, nifa, tdgia'
    # datasets = ['polblogs', 'cora_ml', 'cora', 'citeseer', 'pubmed', 'dblp']
    datasets = ['cora_ml', 'cora', 'citeseer', 'pubmed']

    perturbation_rates = [0.05, 0.1, 0.15, 0.2, 0.25]

    averages = []
    std_devs = []

    for data in datasets:
        for ptb_rate in perturbation_rates:
            results = []
            # Run 10 iterations for statistical robustness
            for n in range(1, 11, 1):
                attack = 'meta'
                parser.set_defaults(dataset=data)
                parser.set_defaults(ptb_rate=ptb_rate)
                args = parser.parse_args()
                args.seed = 15 + n

                result = main(1, args, attack)  # Seed fixed at 1 for simplicity
                results.append(result)

            # Calculate average and standard deviation
            average = np.mean(results)
            std_dev = np.std(results)
            averages.append(average)
            std_devs.append(std_dev)

    index = 0
    for data in datasets:
        print(f"Dataset: {data}")
        for ptb_rate in perturbation_rates:
            print(f"  ptb_rate: {ptb_rate}, Average±Std Dev: {averages[index]:.4f}±{std_devs[index]:.4f}")
            index += 1





