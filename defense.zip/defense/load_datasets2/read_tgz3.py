import os
from torch_geometric.datasets import GitHub  # 替换为实际的模块名

# 设置数据集的根目录
root = '/home/chenwenxiong/project/defense/Fea_NAN_dataset/save'  # 替换为您希望保存数据集的路径

# 创建数据集实例
dataset = GitHub(root=root)

# 访问数据集中的数据
data = dataset[0]  # 获取第一个数据对象

# 打印一些基本信息
print(f'节点特征: {data.x}')
print(f'标签: {data.y}')
print(f'边索引: {data.edge_index}')

# 查看节点和边的数量
num_nodes = data.num_nodes
num_edges = data.edge_index.size(1)  # edge_index的第二个维度表示边的数量
num_classes = dataset.num_classes  # 注意：这里需要在 GitHub 类中添加 num_classes 属性

print(f'节点个数: {num_nodes}')
print(f'边数: {num_edges}')
print(f'标签数: {num_classes}')