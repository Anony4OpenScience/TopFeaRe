import numpy as np
import rdflib
from collections import Counter
import scipy
from torch_geometric.datasets import Entities
from torch_geometric.utils import index_sort
import torch
import scipy.sparse as sp




# 设置根目录（请根据您的文件系统结构更改此路径）
root_dir = '/home/chenwenxiong/project/defense/Fea_NAN_dataset/save'  # 替换为实际路径

# 创建 Entities 对象
dataset_name = 'mutag'  # 或者 'aifb','mutag', 'bgs', 'am'
entities = Entities(root=root_dir, name=dataset_name, hetero=False)

# 访问图数据
data = entities[0]  # 获取数据
print(data)


# 查看节点和边的数量
num_nodes = data.num_nodes
num_edges = data.edge_index.size(1)  # edge_index的第二个维度表示边的数量
num_classes = entities.num_classes

print(f'节点个数: {num_nodes}')
print(f'边数: {num_edges}')
print(f'标签数: {num_classes}')

print(entities.num_classes)

# 将邻接矩阵转换为稀疏矩阵格式
adjacency_matrix = torch.zeros((num_nodes, num_nodes), dtype=torch.float32)

# 填充邻接矩阵
edge_index = data.edge_index.numpy()
for i in range(num_edges):
    sender = edge_index[0, i]
    receiver = edge_index[1, i]
    adjacency_matrix[sender, receiver] = 1.0  # 或者设置为 1

# 将稀疏矩阵转换为 CSR 格式
adj_sparse = sp.csr_matrix(adjacency_matrix.numpy())

# 初始化所有节点的标签为 -1（表示未标记）
all_labels = 1.5 * np.ones(data.num_nodes, dtype=int)

# 填充训练集标签
if data.train_y is not None:
    train_labels = data.train_y.numpy()  # 将训练标签转换为 NumPy 数组
    all_labels[data.train_idx.numpy()] = train_labels  # 将训练标签填入对应的索引

# print("train_idx: ", data.train_idx)
# print("test_idx: ", data.test_idx)
#
# print("train_idx: ", data.train_idx.numpy())
# print("test_idx: ", data.test_idx.numpy())


# 填充测试集标签（如果需要）
if data.test_y is not None:
    test_labels = data.test_y.numpy()  # 将测试标签转换为 NumPy 数组
    all_labels[data.test_idx.numpy()] = test_labels  # 将测试标签填入对应的索引

# 打印所有节点的标签
print("所有节点的标签:")
for index, label in enumerate(all_labels):
    print(f"节点 {index}: 标签 {label}")
#
#
#
# 保存为 npz 文件
np.savez('/home/chenwenxiong/project/defense/test_save/mutag.npz',
         adj_data=adj_sparse.data,
         adj_indices=adj_sparse.indices,
         adj_indptr=adj_sparse.indptr,
         adj_shape=adj_sparse.shape,
         labels=all_labels)  # 假设 train_y 是标签
#
#
data = np.load('/home/chenwenxiong/project/defense/test_save/mutag.npz')

print(data.files)
# print(labels_tensor)
# 获取各个键对应的值
adj_data = data['adj_data']
adj_indices = data['adj_indices']
adj_indptr = data['adj_indptr']
adj_shape = data['adj_shape']
labels = data['labels']


# 打印各个值
print("adj_data:")
print(adj_data)

print("adj_indices:")
print(adj_indices)

print("adj_indptr:")
print(adj_indptr)

print("adj_shape:")
print(adj_shape)

print("labels:")
print(labels)
print(len(labels))





