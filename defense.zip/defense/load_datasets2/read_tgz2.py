import os
# from torch_geometric.datasets import RelLinkPredDataset  # 替换为实际的模块名
from download_dataset2 import RelLinkPredDataset

# 设置数据集的根目录
root = '/home/chenwenxiong/project/defense/Fea_NAN_dataset/save'  # 替换为您希望保存数据集的路径

# 创建数据集实例
dataset = RelLinkPredDataset(root=root, name='FB15k-237')

# 访问数据集中的数据
data = dataset[0]  # 获取第一个数据对象

# 打印一些基本信息
print(f'Number of nodes: {data.num_nodes}')
print(f'Edge index: {data.edge_index}')
print(f'Edge type: {data.edge_type}')
print(f'Training edge index: {data.train_edge_index}')
print(f'Validation edge index: {data.valid_edge_index}')
print(f'Test edge index: {data.test_edge_index}')