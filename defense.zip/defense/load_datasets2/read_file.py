from torch_geometric.datasets import TUDataset
import os.path as osp


def get_dataset(dataset, regression=False, multi_target_regression=False):
    path = osp.join(osp.dirname(osp.realpath(__file__)), '..', 'datasets', dataset)
    TUDataset(path, name=dataset)


dataset = "aifb"

get_dataset(dataset)