import numpy as np
import gzip
import scipy.sparse as sp

# # 加载 GitHub 数据集
# data = np.load('/home/chenwenxiong/project/defense/tmp2/github.npz')
#
# # 提取 edges 和 features
# edges = data['edges']
# features = data['features']
# labels = data['labels']
#
# # 创建一个空的邻接矩阵
# communication_matrix = {}
#
# # 将边缘数据转换为邻接矩阵
# for edge in edges:
#     sender, receiver = edge
#     if sender not in communication_matrix:
#         communication_matrix[sender] = set()
#     communication_matrix[sender].add(receiver)
#
#     if receiver not in communication_matrix:
#         communication_matrix[receiver] = set()
#     communication_matrix[receiver].add(sender)
#
# # 创建邻接矩阵
# num_nodes = max(communication_matrix.keys()) + 1
# adjacency_matrix = [[0 for _ in range(num_nodes)] for _ in range(num_nodes)]
#
# for sender, receivers in communication_matrix.items():
#     for receiver in receivers:
#         adjacency_matrix[sender][receiver] = 1
#
# # 转换为稀疏矩阵
# adj_sparse = sp.csr_matrix(adjacency_matrix)
# print("稀疏矩阵的维度：", adj_sparse.shape)
#
# # 假设标签是从特征中提取的，您可以直接使用 labels
# labels = np.array(labels)
#
# # 保存到 .npz 文件
# np.savez('/home/chenwenxiong/project/defense/tmp1/github.npz',
#          adj_data=adj_sparse.data,
#          adj_indices=adj_sparse.indices,
#          adj_indptr=adj_sparse.indptr,
#          adj_shape=adj_sparse.shape,
#          labels=labels)

# data = np.load('/home/chenwenxiong/project/defense/tmp9/github.npz')
#
#
#
# print(data.files)
#
#
# adj_data = data['adj_data']
# adj_indices = data['adj_indices']
# adj_indptr = data['adj_indptr']
# adj_shape = data['adj_shape']
# labels = data['labels']
#
# # 打印各个值
# print("adj_data:")
# print(adj_data)
#
# print("adj_indices:")
# print(adj_indices)
#
# print("adj_indptr:")
# print(adj_indptr)
#
# print("adj_shape:")
# print(adj_shape)
#
# print("labels:")
# print(labels)
# print(len(labels))

# # 加载数据
# data = np.load('/home/chenwenxiong/project/defense/tmp1/github.npz')
#
# # 提取邻接矩阵的形状
# adj_shape = data['adj_shape']
# num_nodes = adj_shape[0]  # 假设是一个方阵，节点数等于行数或列数
#
# # 生成节点索引数组
# node_indices = np.arange(num_nodes)
#
# # 打印结果
# print("节点数:", num_nodes)
# print("节点索引数组:", node_indices)

data = np.load('/home/chenwenxiong/project/defense/tmp1/github.npz')

# 提取邻接矩阵的形状
adj_shape = data['adj_shape']
num_nodes = adj_shape[0]  # 假设是一个方阵，节点数等于行数或列数

# 生成节点索引数组
node_indices = np.arange(num_nodes)
# 查找值为0的索引
indices_of_zero = [index for index, value in enumerate(node_indices) if value == 0]

# 打印结果
print("值为0的索引:", indices_of_zero)