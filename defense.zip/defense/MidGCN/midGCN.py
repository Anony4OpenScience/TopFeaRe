import argparse
from deeprobust.graph.utils import *
from deeprobust.graph.data import PrePtbDataset, Dpr2Pyg
from defense.load_datasets.attacked_data2 import PrePtbDataset
from defense.load_datasets.dataset2 import Dataset
from feature_flip_utils import feature_flip
from process import process
from model import DeepGCN
from scipy.sparse import csr_matrix

parser = argparse.ArgumentParser()
parser.add_argument('--seed', type=int, default=15, help='Random seed.')
parser.add_argument('--dataset', type=str, default='polblogs',
                    choices=['email', 'aifb', 'cora', 'cora_ml', 'citeseer', 'polblogs', 'pubmed'], help='dataset')
parser.add_argument('--ptb_rate', type=float, default=0.05, help='pertubation rate')

parser.add_argument('--epochs', type=int, default=200, help='Number of epochs to train.')  # 300
parser.add_argument('--wd', type=float, default=5e-4, help='Weight decay (L2 loss on parameters).')
parser.add_argument('--lr', type=float, default=0.01, help='Initial learning rate.')  # 0.005
parser.add_argument('--dropout', type=float, default=0.6, help='Dropout rate.')
parser.add_argument('--nlayer', type=int, default=2, help='Number of layers, works for Deep model.')
parser.add_argument('--combine', type=str, default='mul', help='{add, mul}}')
parser.add_argument('--hid', type=int, default=256, help='Number of hidden units.')
parser.add_argument('--alpha', type=float, default=0.5, help='hyperparameters.')
parser.add_argument('--feature_flip', type=int, default=0, help='Random flip features.')
OUT_PATH = "/root/"

args = parser.parse_args()
args.cuda = torch.cuda.is_available()
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")


def train(net, optimizer, data):
    net.train()
    optimizer.zero_grad()
    output, output_list = net(data.x, data)
    loss_train = F.nll_loss(output[data.train_mask], data.y[data.train_mask])
    loss = loss_train
    acc = accuracy(output[data.train_mask], data.y[data.train_mask])
    loss.backward()
    optimizer.step()

    return loss, acc


def val(net, data):
    net.eval()
    output, output_list = net(data.x, data)
    loss_val = F.nll_loss(output[data.val_mask], data.y[data.val_mask])
    acc_val = accuracy(output[data.val_mask], data.y[data.val_mask])
    return loss_val, acc_val


def test(net, data):
    net.eval()
    output, output_list = net(data.x, data)
    loss_test = F.nll_loss(output[data.test_mask], data.y[data.test_mask])
    acc_test = accuracy(output[data.test_mask], data.y[data.test_mask])
    return loss_test, acc_test


acc_all = []


# def main(n, i, ptbrate):
def main(n, args, attack):
    data = Dataset(root=f'/root/', name=args.dataset, setting='prognn')
    adj, features, labels = data.adj, data.features, data.labels
    idx_train, idx_val, idx_test = data.idx_train, data.idx_val, data.idx_test

    pyg_data = Dpr2Pyg(data)

    features = pyg_data.x.cpu().detach().numpy()

    if args.dataset == 'cora_ml' or args.dataset == 'cora' or args.dataset == 'citeseer':
        features = np.eye(adj.shape[0])
        features = csr_matrix(features)
    # features = sp.csr_matrix(features)


    # load pre-attacked graph nettack meta,pgd,minmax,dice
    perturbed_data = PrePtbDataset(root=f'/root/',
                                   name=args.dataset,
                                   attack_method=attack,
                                   ptb_rate=args.ptb_rate)
    perturbed_adj = perturbed_data.adj


    target_nodes = perturbed_data.target_nodes
    if attack == 'nettack':
        idx_test = target_nodes


    perturbed_feature = feature_flip(args.dataset, args.feature_flip, features, idx_train)
    data = process(perturbed_adj, perturbed_feature, labels, idx_train, idx_val, idx_test, args.alpha)

    net = DeepGCN(perturbed_feature.shape[1], args.hid, labels.max().item() + 1,
                  dropout=args.dropout,
                  combine=args.combine,
                  nlayer=args.nlayer)

    net = net.to(device)
    net = net.to(device)
    optimizer = torch.optim.Adam(net.parameters(), args.lr, weight_decay=args.wd)

    # train
    best_acc = 0
    best_loss = 1e10
    import time
    s = time.time()
    for epoch in range(args.epochs):
        train_loss, train_acc = train(net, optimizer, data)
        val_loss, val_acc = val(net, data)
        test_loss, test_acc = test(net, data)

        print('Epoch %d: train loss %.3f train acc: %.3f, val loss: %.3f val acc %.3f | test acc %.3f.' %
              (epoch, train_loss, train_acc, val_loss, val_acc, test_acc))

        # save model
        if best_acc < val_acc:
            best_acc = val_acc
            torch.save(net.state_dict(),
                       OUT_PATH + 'checkpoint-best-acc' + str(args.nlayer) + str(args.dataset) + '.pkl')
        # if best_loss > val_loss:
        #     best_loss = val_loss
        #     torch.save(net.state_dict(), OUT_PATH+'checkpoint-best-loss'+str(args.nlayer) + str(args.data) + '.pkl')

    e = time.time()
    print("avr epoch time:", (e - s) / args.epochs)
    # pick up the best model based on val_acc, then do test
    net.load_state_dict(torch.load(OUT_PATH + 'checkpoint-best-acc' + str(args.nlayer) + str(args.dataset) + '.pkl'))

    val_loss, val_acc = val(net, data)
    test_loss, test_acc = test(net, data)

    return test_acc.cpu().numpy()


# 0.8330
if __name__ == '__main__':

    'cora_ml', 'cora', 'citeseer', 'pubmed'
    'meta, pgd, nifa, tdgia'
    # datasets = ['polblogs', 'cora_ml', 'cora', 'citeseer', 'pubmed', 'dblp']
    datasets = ['cora_ml', 'cora', 'citeseer', 'pubmed']

    perturbation_rates = [0.05, 0.1, 0.15, 0.2, 0.25]

    averages = []
    std_devs = []

    for data in datasets:
        for ptb_rate in perturbation_rates:
            results = []
            # Run 10 iterations for statistical robustness
            for n in range(1, 11, 1):
                attack = 'meta'
                parser.set_defaults(dataset=data)
                parser.set_defaults(ptb_rate=ptb_rate)
                args = parser.parse_args()
                args.seed = 15 + n

                result = main(1, args, attack)  # Seed fixed at 1 for simplicity
                results.append(result)

            # Calculate average and standard deviation
            average = np.mean(results)
            std_dev = np.std(results)
            averages.append(average)
            std_devs.append(std_dev)

    index = 0
    for data in datasets:
        print(f"Dataset: {data}")
        for ptb_rate in perturbation_rates:
            print(f"  ptb_rate: {ptb_rate}, Average±Std Dev: {averages[index]:.4f}±{std_devs[index]:.4f}")
            index += 1


