import numpy as np
import torch
import argparse
from defense.precode.pyg_dataset import Dpr2Pyg
from deeprobust.graph.defense import GAT
from defense.load_datasets.dataset2 import Dataset
from defense.load_datasets.attacked_data2 import PrePtbDataset
from defense.load_datasets.gat2 import GAT
from scipy.sparse import csr_matrix

parser = argparse.ArgumentParser()
parser.add_argument('--seed', type=int, default=15, help='Random seed.')
parser.add_argument('--dataset', type=str, default='citeseer', choices=['email','aifb','cora', 'cora_ml', 'citeseer', 'polblogs', 'pubmed'], help='dataset')
parser.add_argument('--ptb_rate', type=float, default=0.05,  help='perturbation rate')


args = parser.parse_args()
args.cuda = torch.cuda.is_available()
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")



parser = argparse.ArgumentParser()
parser.add_argument('--seed', type=int, default=15, help='Random seed.')
parser.add_argument('--dataset', type=str, default='citeseer', choices=['email','aifb','cora', 'cora_ml', 'citeseer', 'polblogs', 'pubmed'], help='dataset')
parser.add_argument('--ptb_rate', type=float, default=0.05,  help='perturbation rate')


args = parser.parse_args()
args.cuda = torch.cuda.is_available()
print('cuda: %s' % args.cuda)
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")


def main(n,args,attack):
    # use data splist provided by prognn
    data = Dataset(root=f'/root/', name=args.dataset, setting='prognn')
    adj, features, labels = data.adj, data.features, data.labels
    idx_train, idx_val, idx_test = data.idx_train, data.idx_val, data.idx_test

    if args.dataset == 'cora_ml' or args.dataset == 'cora' or args.dataset == 'citeseer':
        features = np.eye(adj.shape[0])
        features = csr_matrix(features)

    print('==================')
    print('=== load graph perturbed by Zugner metattack (under prognn splits) ===')


    perturbed_data = PrePtbDataset(root=f'/root/',
            name=args.dataset,
            attack_method=attack,
            ptb_rate=args.ptb_rate)
    perturbed_adj = perturbed_data.adj
    new_nodes = perturbed_adj.shape[0]
    perturbed_feature = perturbed_data.feature


    target_nodes = perturbed_data.target_nodes
    if attack == 'nettack':
        idx_test = target_nodes


    if new_nodes > len(labels):
        new_labels = np.concatenate([labels, -1 * np.ones(new_nodes - len(labels), dtype=labels.dtype)])
        data.labels = new_labels

        train_mask_clean = np.zeros(len(labels), dtype=bool)
        val_mask_clean = np.zeros(len(labels), dtype=bool)
        test_mask_clean = np.zeros(len(labels), dtype=bool)

        train_mask_clean[idx_train] = True
        val_mask_clean[idx_val] = True
        test_mask_clean[idx_test] = True

        new_train_mask = np.concatenate([train_mask_clean, np.zeros(new_nodes - len(labels), dtype=bool)])
        new_val_mask = np.concatenate([val_mask_clean, np.zeros(new_nodes - len(labels), dtype=bool)])
        new_test_mask = np.concatenate([test_mask_clean, np.zeros(new_nodes - len(labels), dtype=bool)])

        data.idx_train = np.where(new_train_mask)[0]
        data.idx_val = np.where(new_val_mask)[0]
        data.idx_test = np.where(new_test_mask)[0]




    gat = GAT(nfeat=features.shape[1],
          nhid=8, heads=8,
          nclass=int(labels.max().item() + 1),
          dropout=0.5, device=device)
    gat = gat.to(device)

    data.adj, data.features = perturbed_data.adj, features

    pyg_data = Dpr2Pyg(data)






    pyg_data.update_edge_index(perturbed_adj) # inplace operation

    gat.fit(pyg_data, verbose=True) # train with earlystopping
    gat.test()

    return gat.test()

if __name__ == '__main__':

    'polblogs', 'cora_ml', 'cora', 'citeseer', 'pubmed', 'dblp'
    'meta, pgd, nifa, tdgia'
    # datasets = ['polblogs', 'cora_ml', 'cora', 'citeseer', 'pubmed', 'dblp']
    datasets = ['cora_ml', 'cora', 'citeseer']
    perturbation_rates = [0.05, 0.1, 0.15, 0.2, 0.25]


    averages = []
    std_devs = []

    attack = 'meta'


    for data in datasets:
        for ptb_rate in perturbation_rates:
            results = []
            # Run 10 iterations for statistical robustness
            for n in range(1, 11, 1):
                parser.set_defaults(dataset=data)
                parser.set_defaults(ptb_rate=ptb_rate)
                args = parser.parse_args()

                result = main(1, args, attack)  # Seed fixed at 1 for simplicity
                results.append(result)

            # Calculate average and standard deviation
            average = np.mean(results)
            std_dev = np.std(results)
            averages.append(average)
            std_devs.append(std_dev)

    # Print results with dataset included
    index = 0
    for data in datasets:
        print(f"Dataset: {data}")
        for ptb_rate in perturbation_rates:
            print(f"  ptb_rate: {ptb_rate}, Average±Std Dev: {averages[index]:.4f}±{std_devs[index]:.4f}")
            index += 1

