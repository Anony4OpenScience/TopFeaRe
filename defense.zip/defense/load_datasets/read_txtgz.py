import gzip
import numpy as np
import scipy.sparse as sp
import torch
from torch_geometric.data import Data, InMemoryDataset, download_url

# with gzip.open('/home/chenwenxiong/tmp/CN03/defense/tmp/email-Eu/email-Eu-core-department-labels.txt.gz', 'rt') as f:
#     for line in f:
#         print(line)
#
# print("------------------------")


# communication_matrix = np.zeros((1005, 1005))
#
# with gzip.open('/home/chenwenxiong/tmp/CN03/defense/tmp/email-Eu/email-Eu-core.txt.gz', 'rt') as f:
#     for line in f:
#         print(line)
#         sender, receiver = map(int, line.strip().split())
#         communication_matrix[sender][receiver] = 1

# # 创建一个空的邻接矩阵
# communication_matrix = {}
#
# # 读取压缩文件并逐行处理
# with gzip.open('/home/chenwenxiong/project/defense/tmp/email-Eu-core.txt.gz', 'rt') as f:
#     for line in f:
#         sender, receiver = map(int, line.strip().split())
#
#         # 将发件人和收件人添加到邻接矩阵中
#         if sender not in communication_matrix:
#             communication_matrix[sender] = set()
#         communication_matrix[sender].add(receiver)
#
#         if receiver not in communication_matrix:
#             communication_matrix[receiver] = set()
#         communication_matrix[receiver].add(sender)
#
# # 创建邻接矩阵
# num_nodes = max(communication_matrix.keys()) + 1
# adjacency_matrix = [[0 for _ in range(num_nodes)] for _ in range(num_nodes)]
#
# for sender, receivers in communication_matrix.items():
#     for receiver in receivers:
#         adjacency_matrix[sender][receiver] = 1
#
# adj_sparse = sp.csr_matrix(adjacency_matrix)
# print("稀疏矩阵的维度：", adj_sparse.shape)
#
# department_ids = [1] * 1005
#
# with gzip.open('/home/chenwenxiong/project/defense/tmp/email-Eu-core-department-labels.txt.gz', 'rt') as f2:
#     for line in f2:
#         member_id, department_id = map(int, line.strip().split())
#         if member_id < 1005:
#             department_ids[member_id] = department_id
#
#
# department_ids_subset = department_ids[:1005]
# department_ids_subset_np = np.array(department_ids_subset)
#
#
#
# department_ids_subset = [id for id in department_ids_subset]
#
#
# np.savez('/home/chenwenxiong/project/defense/tmp10/email.npz', adj_data=adj_sparse.data, adj_indices=adj_sparse.indices,
#          adj_indptr=adj_sparse.indptr, adj_shape=adj_sparse.shape, labels=department_ids_subset_np)

#'/home/chenwenxiong/project/defense/test_save/aifb.npz'
#'/home/chenwenxiong/project/defense/tmp1/polblogs.npz'
data = np.load('/home/chenwenxiong/project/defense/tmp1/polblogs.npz')  # polblogs\github
# Polblogs: ['adj_data', 'adj_indices', 'adj_indptr', 'adj_shape', 'labels']
# Cora: ['attr_shape', 'attr_indptr', 'adj_data', 'attr_indices', 'adj_shape', 'labels', 'idx_to_node', 'adj_indices', 'attr_data', 'idx_to_class', 'adj_indptr']
# Cora_ml['adj_data', 'adj_indices', 'adj_indptr', 'adj_shape', 'attr_data', 'attr_indices', 'attr_indptr', 'attr_shape', 'labels', 'node_names', 'attr_names', 'class_names']


adj_data = data['adj_data']
adj_indices = data['adj_indices']
adj_indptr = data['adj_indptr']
adj_shape = data['adj_shape']
labels = data['labels']

# 打印各个值
print("adj_data:")
print(adj_data)

print("adj_indices:")
print(adj_indices)

print("adj_indptr:")
print(adj_indptr)

print("adj_shape:")
print(adj_shape)

print("labels:")
print(labels)
print(len(labels))

for i, label in enumerate(labels):
    print(f"Node {i}: Department ID {label}")










# # 加载数据
# data = np.load('/home/chenwenxiong/project/defense/tmp2/github.npz')  # polblogs\github
#
# # 打印所有的键
# print("文件中的键:", data.files)
#
# # 获取各个键对应的值
# edges = data['edges']
# features = data['features']
# target = data['target']
#
# # 创建 Data 对象
# data = Data(x=torch.from_numpy(features), y=torch.from_numpy(target), edge_index=torch.from_numpy(edges))
# data.labels = data.y  # 将 labels 指向 y
# del data.y  # 删除 y 属性
#
# # 打印新的 labels
# print("labels:")
# print(data.labels)
#
# # 打印 labels 的长度
# print("labels 的长度:", len(data.labels))
#
# # 保存新的数据
# np.savez('/home/chenwenxiong/project/defense/tmp2/github.npz',
#          edges=edges,
#          features=features,
#          labels=data.labels.numpy())  # 将 labels 转换为 numpy 数组并保存

# # 重新加载数据
# data2 = np.load('/home/chenwenxiong/project/defense/tmp3/github.npz')
#
# # 通过键名访问 labels
# print("labels:")
# print(data2['labels'])  # 使用键名访问 labels



