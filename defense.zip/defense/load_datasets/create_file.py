import networkx as nx
import numpy as np
import scipy.sparse as sp
import torch
from networkx.algorithms import community

# 读取GML文件
G = nx.read_gml('/home/chenwenxiong/tmp/CN03/defense/tmp/dolphins/dolphins.gml')

# 划分社团
communities = community.greedy_modularity_communities(G)

# 将每个节点分配到两个社团中，并将社团标签信息记录到节点的label属性中
for i, comm in enumerate(communities):
    for node in comm:
        G.nodes[node]['label'] = i

# 输出每个节点的社团标签
for node in G.nodes():
    print(f"Node {node} belongs to community {G.nodes[node]['label']}")

# 创建一个空字典用于存储节点标签
labels = {}

# 遍历图G的节点，提取标签信息
for node in G.nodes(data=True):
    node_id = node[0]
    label = node[1].get('label')  # 假设标签信息存储在'label'属性中
    if label is not None:
        labels[node_id] = label
    else:
        print(f"Node {node_id} does not have a label")

# 打印节点标签
for node_id, label in labels.items():
    print(f"Node {node_id} has label: {label}")

labels_array = np.array(list(labels.values()))

# 转换为邻接矩阵
adj_data = nx.to_numpy_array(G)

# 转换为稀疏矩阵
adj_sparse = sp.csr_matrix(adj_data)
# labels_tensor = torch.tensor(labels_array)


# 保存为npz文件
np.savez('/home/chenwenxiong/tmp/CN03/defense/tmp/dolphins.npz', adj_data=adj_sparse.data, adj_indices=adj_sparse.indices, adj_indptr=adj_sparse.indptr, adj_shape=adj_sparse.shape, labels = labels_array)



# 读取npz文件
data = np.load('/home/chenwenxiong/tmp/CN03/defense/tmp/dolphins.npz')# polblogs:2\dolphins:3\cora:7\cora_ml:7\citeseer:6
# Polblogs: ['adj_data', 'adj_indices', 'adj_indptr', 'adj_shape', 'labels']
# Cora: ['attr_shape', 'attr_indptr', 'adj_data', 'attr_indices', 'adj_shape', 'labels', 'idx_to_node', 'adj_indices', 'attr_data', 'idx_to_class', 'adj_indptr']
# Cora_ml['adj_data', 'adj_indices', 'adj_indptr', 'adj_shape', 'attr_data', 'attr_indices', 'attr_indptr', 'attr_shape', 'labels', 'node_names', 'attr_names', 'class_names']
# 打印所有键
print(data.files)
# print(labels_tensor)
# 获取各个键对应的值
adj_data = data['adj_data']
adj_indices = data['adj_indices']
adj_indptr = data['adj_indptr']
adj_shape = data['adj_shape']
labels = data['labels']

# 打印各个值
print("adj_data:")
print(adj_data)

print("adj_indices:")
print(adj_indices)

print("adj_indptr:")
print(adj_indptr)

print("adj_shape:")
print(adj_shape)

print("labels:")
print(labels)

i = 0
for label in labels:
    print(i)
    print(label)
    i = i + 1


print(','.join(str(i) for i in range(1005)))
