import networkx as nx
import numpy as np
import scipy.sparse as sp


import networkx as nx
from networkx.algorithms import community

# # 读取GML文件
# G = nx.read_gml('/home/chenwenxiong/tmp/CN03/defense/tmp/dolphins/dolphins.gml')
#
#
# # 获取所有节点的键
# node_keys = G.nodes.keys()
#
# # 获取所有边的键
# edge_keys = G.edges.keys()
#
# print("Node keys:", node_keys)
# print("Edge keys:", edge_keys)





# # 读取npz文件
# data = np.load('/tmp/CN03/defense/tmp/dolphins.npz')
#
# # 从npz文件中获取邻接矩阵
# adj_matrix = data['adj_matrix']
#
# # 计算边数
# num_nodes = int(np.sum(adj_matrix) / 2)  # 由于邻接矩阵是对称的，所以每条边会被计算两次，因此要除以2
#
# print("节点数:", num_nodes)

# import random
#
# # 生成包含159个整数的列表
# all_numbers = list(range(0, 1005))
#
# # 打乱列表顺序
# random.shuffle(all_numbers)
#
# # 计算各个集合的大小
# total_len = len(all_numbers)
# train_len = int(total_len * 0.1)
# val_len = int(total_len * 0.1)
# test_len = total_len - train_len - val_len
#
# # 分割列表
# idx_train = all_numbers[:train_len]
# idx_val = all_numbers[train_len:train_len + val_len]
# idx_test = all_numbers[train_len + val_len:]
# #
# # 将结果组装成字典
# result = {"idx_train": idx_train, "idx_val": idx_val, "idx_test": idx_test}
#
# print(result)

# import random
#
# # 生成包含159个整数的列表
# all_numbers = list(range(1, 160))
#
# # 打乱列表顺序
# random.shuffle(all_numbers)
#
# # 计算各个集合的大小
# total_len = len(all_numbers)
# train_len = int(total_len * 0.1)
# val_len = int(total_len * 0.1)
# test_len = total_len - train_len - val_len
#
# # 分割列表
# idx_train = all_numbers[:train_len]
# idx_val = all_numbers[train_len:train_len + val_len]
# idx_test = all_numbers[train_len + val_len:]
#
# # 将结果组装成字典
# result = {"idx_train": idx_train, "idx_val": idx_val, "idx_test": idx_test}
#
# print(result)