import numpy as np
import torch
import scipy.sparse as sp

from scipy.sparse import csr_matrix

# 获取当前节点的邻居节点个数
def get_X(adj_matrix, node_index):
    # 确保 adj_matrix 是张量
    if isinstance(adj_matrix, np.ndarray):
        adj_matrix = torch.tensor(adj_matrix).cuda(0)  # 将 NumPy 数组转换为张量并放到 cuda:0 上
    return torch.sum(adj_matrix[node_index]).item()  # 使用 .item() 转换为 Python 标量


# 获取当前节点与邻居节点的特征差异
def get_F(adj_matrix, node_index, node_features):
    # 确保 adj_matrix 是张量
    if isinstance(adj_matrix, np.ndarray):
        adj_matrix = torch.tensor(adj_matrix).cuda(0)  # 将 NumPy 数组转换为张量并放到 cuda:0 上

    current_feature = node_features[node_index]  # 获取当前节点的特征
    neighbors = torch.where(adj_matrix[node_index] == 1)[0]  # 找到邻居节点的索引
    total_difference = 0.0  # 初始化为0.0，确保是浮点数

    for neighbor in neighbors:
        neighbor_feature = node_features[neighbor]  # 获取邻居节点的特征
        difference = torch.sum(current_feature - neighbor_feature)  # 计算特征差异的总和
        difference_abs = torch.abs(difference)
        total_difference += difference_abs.item()  # 将特征差异相加

    return total_difference  # 返回总差异


# def caculate_YxYf(A, features, node1, node2):
#     # # 确保 features 是一个密集矩阵
#     # if isinstance(features, csr_matrix):
#     #     features = torch.tensor(features.toarray()).cuda(0)  # 将稀疏矩阵转换为密集矩阵并放到 cuda:0 上
#     # else:
#     #     features = torch.tensor(features).cuda(0)  # 如果已经是密集矩阵，直接转换并放到 cuda:0 上
#
#
#     Y1_node1=0
#     Y2_node1=0
#
#     Y1_node2 = 0
#     Y2_node2 = 0
#
#
#     sum_total_feature_diff1 = 0
#     sum_total_feature_diff2 = 0
#     sum_count1 = 0
#     sum_count2 = 0
#
#     # 确保 A 是张量
#     if isinstance(A, np.ndarray):
#         A = torch.tensor(A).cuda(0)  # 将 NumPy 数组转换为张量并放到 cuda:0 上
#
#     '节点邻居个数'
#     count1 = get_X(A, node1)
#     count2 = get_X(A, node2)
#
#     '邻居节点特征差异值和'
#     total_feature_diff1 = get_F(A, node1, features)
#     total_feature_diff2 = get_F(A, node2, features)
#
#     if total_feature_diff1 == 0:
#         return 0, 0, 0, 0  # 或者返回 (0, 0, 0, 0) 作为默认值
#     if total_feature_diff2 == 0:
#         return 0, 0, 0, 0  # 或者返回 (0, 0, 0, 0) 作为默认值
#
#     # sum_total_feature_diff1 += total_feature_diff1
#     # sum_total_feature_diff2 += total_feature_diff2
#     # sum_count1 += count1
#     # sum_count2 += count2
#
#     Y1_node1 += total_feature_diff1 / count1
#     Y2_node1 += count1 / total_feature_diff1
#
#     Y1_node2 += total_feature_diff2 / count2
#     Y2_node2 += count2 / total_feature_diff2
#
#
#     return Y1_node1, Y2_node1, Y1_node2, Y2_node2
def caculate_YxYf(A, features, node1, node2):
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

    # 统一转换稀疏矩阵
    features = convert_to_dense(features, device)

    # 确保 A 是张量
    A = convert_to_dense(A, device)

    Y1_node1 = 0
    Y2_node1 = 0
    Y1_node2 = 0
    Y2_node2 = 0

    # 计算邻居节点个数
    count1 = get_X(A, node1)
    count2 = get_X(A, node2)

    # 计算邻居节点特征差异值和
    total_feature_diff1 = get_F(A, node1, features)
    total_feature_diff2 = get_F(A, node2, features)

    if total_feature_diff1 == 0 or count1 == 0:
        return 0, 0, 0, 0

    if total_feature_diff2 == 0 or count2 == 0:
        return 0, 0, 0, 0

    Y1_node1 += total_feature_diff1 / count1
    Y2_node1 += count1 / total_feature_diff1

    Y1_node2 += total_feature_diff2 / count2
    Y2_node2 += count2 / total_feature_diff2

    return Y1_node1, Y2_node1, Y1_node2, Y2_node2


def convert_to_dense(matrix, device):
    """将各种格式的稀疏矩阵转换为密集张量"""
    if isinstance(matrix, torch.Tensor):
        return matrix.to(device)

    if sp.issparse(matrix):
        # 转换为COO格式再转密集矩阵（适用于所有稀疏类型）
        coo = matrix.tocoo()
        indices = torch.stack([
            torch.tensor(coo.row, dtype=torch.long),
            torch.tensor(coo.col, dtype=torch.long)
        ]).to(device)
        values = torch.tensor(coo.data, dtype=torch.float32).to(device)
        sparse_tensor = torch.sparse.FloatTensor(indices, values, coo.shape).to(device)
        return sparse_tensor.to_dense()

    # 如果是NumPy数组，直接转换为张量
    return torch.tensor(matrix, dtype=torch.float32).to(device)