import argparse
from deeprobust.graph.utils import *
from defense.load_datasets.dataset2 import Dataset
from defense.load_datasets.attacked_data2 import PrePtbDataset
from method import TopFeaRe


parser = argparse.ArgumentParser()
parser.add_argument('--seed', type=int, default=15, help='Random seed.')
parser.add_argument('--dataset', type=str, default='cora_ml', choices=['github_alter','aifb','cora', 'email', 'cora_ml', 'citeseer', 'polblogs', 'pubmed'], help='dataset')
parser.add_argument('--ptb_rate', type=float, default=0.05,  help='pertubation rate')


parser.add_argument('--k', type=int, default=20, help='Truncated Components.')
parser.add_argument('--hidden', type=int, default=16,
                    help='Number of hidden units.')
parser.add_argument('--dropout', type=float, default=0.5,
                    help='Dropout rate (1 - keep probability).')




args = parser.parse_args()


def main(n, args, attack):
    args.cuda = torch.cuda.is_available()
    print('cuda: %s' % args.cuda)
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

    np.random.seed(args.seed)
    if args.cuda:
        torch.cuda.manual_seed(args.seed)
    data = Dataset(root=f'/root/', name=args.dataset, setting='prognn')
    adj, features, labels = data.adj, data.features, data.labels
    idx_train, idx_val, idx_test = data.idx_train, data.idx_val, data.idx_test



    perturbed_data = PrePtbDataset(root=f'/root/',
            name=args.dataset,
            attack_method=attack,
            ptb_rate=args.ptb_rate)
    perturbed_adj = perturbed_data.adj



    target_nodes = perturbed_data.target_nodes
    # if attack == 'nettack':
    #     idx_test = target_nodes




    model = TopFeaRe(nfeat=features.shape[1], nclass=labels.max()+1,
                    nhid=16,device=device)

    model = model.to(device)

    model.fit(features, perturbed_adj, labels, args.ptb_rate, args.dataset, n, attack, idx_train, idx_val, idx_test, k=args.k, verbose=True)
    model.eval()
    output = model.test(idx_test)


    return output


#0.8330
if __name__ == '__main__':

    'cora_ml', 'cora', 'citeseer', 'pubmed'
    'meta, pgd, nifa, tdgia'
    # datasets = ['polblogs', 'cora_ml', 'cora', 'citeseer', 'pubmed', 'dblp']
    datasets = ['cora_ml', 'cora', 'citeseer', 'pubmed']

    perturbation_rates = [0.05, 0.1, 0.15, 0.2, 0.25]

    averages = []
    std_devs = []

    for data in datasets:
        for ptb_rate in perturbation_rates:
            results = []
            # Run 10 iterations for statistical robustness
            for n in range(1, 11, 1):
                attack = 'meta'
                parser.set_defaults(dataset=data)
                parser.set_defaults(ptb_rate=ptb_rate)
                args = parser.parse_args()
                args.seed = 15 + n

                result = main(1, args, attack)  # Seed fixed at 1 for simplicity
                results.append(result)

            # Calculate average and standard deviation
            average = np.mean(results)
            std_dev = np.std(results)
            averages.append(average)
            std_devs.append(std_dev)

    index = 0
    for data in datasets:
        print(f"Dataset: {data}")
        for ptb_rate in perturbation_rates:
            print(f"  ptb_rate: {ptb_rate}, Average±Std Dev: {averages[index]:.4f}±{std_devs[index]:.4f}")
            index += 1



















