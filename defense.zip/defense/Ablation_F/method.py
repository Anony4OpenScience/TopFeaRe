from deeprobust.graph import utils
from deeprobust.graph.defense import GCN
from method_detail import RobustModel




class TopFeaRe(GCN):

    def __init__(self, nfeat, nhid, nclass, dropout=0.5, lr=0.01, weight_decay=5e-4, with_relu=True, with_bias=True, device='cuda:0'):

        super(TopFeaRe, self).__init__(nfeat, nhid, nclass, dropout, lr, weight_decay, with_relu, with_bias, device=device)
        self.device = device
        self.k = None
        self.nhid = nhid
        self.dropout = dropout

    def fit(self, features, adj, labels, ptbrate, dataset, n, attack, idx_train, idx_val, idx_test, k=50, train_iters=200, initialize=True, verbose=True, **kwargs):


        adj = adj.toarray()
        modified_adj = RobustModel(adj, features, ptbrate, dataset, attack)

        features, modified_adj, labels = utils.to_tensor(features, modified_adj, labels, device=self.device)

        self.modified_adj = modified_adj
        self.features = features
        self.labels = labels
        super().fit(features, modified_adj, labels, idx_train, idx_val, train_iters=train_iters, initialize=initialize, verbose=verbose)


