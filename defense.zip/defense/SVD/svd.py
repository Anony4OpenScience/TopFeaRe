import argparse
from deeprobust.graph.utils import *
from defense.load_datasets.dataset2 import Dataset
from defense.load_datasets.attacked_data2 import PrePtbDataset
from deeprobust.graph.defense import GCNSVD


parser = argparse.ArgumentParser()
parser.add_argument('--seed', type=int, default=15, help='Random seed.')
#实验数据集
parser.add_argument('--dataset', type=str, default='citeseer', choices=['email','aifb','cora', 'cora_ml', 'citeseer', 'polblogs', 'pubmed'], help='dataset')
# 0.05-0.50 扰动率
parser.add_argument('--ptb_rate', type=float, default=0.05,  help='pertubation rate')


parser.add_argument('--k', type=int, default=20, help='Truncated Components.')
parser.add_argument('--hidden', type=int, default=16,
                    help='Number of hidden units.')
parser.add_argument('--dropout', type=float, default=0.5,
                    help='Dropout rate (1 - keep probability).')




args = parser.parse_args()




args.cuda = torch.cuda.is_available()
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
args = parser.parse_args()


def main(n, args, attack):

    data = Dataset(root=f'/root/', name=args.dataset, setting='prognn')
    adj, features, labels = data.adj, data.features, data.labels
    idx_train, idx_val, idx_test = data.idx_train, data.idx_val, data.idx_test

    features = np.eye(adj.shape[0])

    # load pre-attacked graph nettack meta,pgd,minmax,dice
    perturbed_data = PrePtbDataset(root=f'/root/',
                                   name=args.dataset,
                                   attack_method=attack,
                                   ptb_rate=args.ptb_rate)
    perturbed_adj = perturbed_data.adj

    if attack == 'nifa' or attack == 'tdgia':
        features = perturbed_data.feature
        # features.data[:] = 1

    target_nodes = perturbed_data.target_nodes
    # if attack == 'nettack':
    #     idx_test = target_nodes


    model = GCNSVD(nfeat=features.shape[1], nclass=labels.max()+1,
                        nhid=16, device=device,)

    model = model.to(device)

    print('=== testing GCN-SVD on perturbed graph ===')
    model.fit(features, perturbed_adj, labels, idx_train, idx_val, k=args.k, verbose=True)
    model.eval()
    output = model.test(idx_test)



    return output




#0.8330
if __name__ == '__main__':

    'cora_ml', 'cora', 'citeseer', 'pubmed'
    'meta, pgd, nifa, tdgia'
    # datasets = ['polblogs', 'cora_ml', 'cora', 'citeseer', 'pubmed', 'dblp']
    datasets = ['cora_ml', 'cora', 'citeseer', 'pubmed']

    perturbation_rates = [0.05, 0.1, 0.15, 0.2, 0.25]

    averages = []
    std_devs = []

    for data in datasets:
        for ptb_rate in perturbation_rates:
            results = []
            # Run 10 iterations for statistical robustness
            for n in range(1, 11, 1):
                attack = 'meta'
                parser.set_defaults(dataset=data)
                parser.set_defaults(ptb_rate=ptb_rate)
                args = parser.parse_args()
                args.seed = 15 + n

                result = main(1, args, attack)  # Seed fixed at 1 for simplicity
                results.append(result)

            # Calculate average and standard deviation
            average = np.mean(results)
            std_dev = np.std(results)
            averages.append(average)
            std_devs.append(std_dev)

    index = 0
    for data in datasets:
        print(f"Dataset: {data}")
        for ptb_rate in perturbation_rates:
            print(f"  ptb_rate: {ptb_rate}, Average±Std Dev: {averages[index]:.4f}±{std_devs[index]:.4f}")
            index += 1



