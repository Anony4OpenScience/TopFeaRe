import torch
import numpy as np
import torch.nn.functional as F
import torch.optim as optim
from deeprobust.graph.defense import GCN
from deeprobust.graph.global_attack import PGDAttack
from deeprobust.graph.utils import *
from deeprobust.graph.data import Dataset
from defense.load_datasets.dataset2 import Dataset
import argparse

# from defense.examples.RobustModel import RobustModel

parser = argparse.ArgumentParser()
parser.add_argument('--seed', type=int, default=15, help='Random seed.')
parser.add_argument('--epochs', type=int, default=100,
                    help='Number of epochs to train.')
parser.add_argument('--dataset', type=str, default='pubmed', choices=['aifb', 'email','cora', 'cora_ml', 'citeseer', 'polblogs', 'pubmed'], help='dataset')
parser.add_argument('--ptb_rate', type=float, default=0.05,  help='pertubation rate')
parser.add_argument('--model', type=str, default='PGD', choices=['PGD', 'min-max'], help='model variant')

args = parser.parse_args()

device = torch.device("cuda:1" if torch.cuda.is_available() else "cpu")

np.random.seed(args.seed)
torch.manual_seed(args.seed)
if device != 'cpu':
    torch.cuda.manual_seed(args.seed)




# def main(n, dataset, ptb_rate):
def main(n, ptb_rate, args):

    def test(new_adj, gcn=None):
        ''' test on GCN '''

        if gcn is None:
            # adj = normalize_adj_tensor(adj)
            gcn = GCN(nfeat=features.shape[1],
                      nhid=16,
                      nclass=labels.max().item() + 1,
                      dropout=0.5, device=device)
            gcn = gcn.to(device)
            # gcn.fit(features, new_adj, labels, idx_train) # train without model picking
            gcn.fit(features, new_adj, labels, idx_train, idx_val, patience=30)  # train with validation model picking
            gcn.eval()
            output = gcn.predict().cpu()
        else:
            gcn.eval()
            output = gcn.predict(features.to(device), new_adj.to(device)).cpu()

        loss_test = F.nll_loss(output[idx_test], labels[idx_test])
        acc_test = accuracy(output[idx_test], labels[idx_test])
        print("Test set results:",
              "loss= {:.4f}".format(loss_test.item()),
              "accuracy= {:.4f}".format(acc_test.item()))

        return acc_test.item()


    data = Dataset(root=f'/root/', name=args.dataset, setting='prognn')

    from torch_geometric.datasets import Planetoid
    from deeprobust.graph.data import Pyg2Dpr
    # dataset = Planetoid('/tmp/CN03/defense/tmp/', name=args.dataset)
    # data = Pyg2Dpr(dataset)

    adj, features, labels = data.adj, data.features, data.labels
    # features = np.eye(adj.shape[0])
    # features = sp.csr_matrix(features, dtype=np.float32)

    features = normalize_feature(features)

    idx_train, idx_val, idx_test = data.idx_train, data.idx_val, data.idx_test

    perturbations = int(args.ptb_rate * (adj.sum()//2))

    # perturbations = 1000

    adj, features, labels = preprocess(adj, features, labels, preprocess_adj=False)

    target_gcn = GCN(nfeat=features.shape[1],
              nhid=16,
              nclass=labels.max().item() + 1,
              dropout=0.5, device=device, lr=0.01)

    target_gcn = target_gcn.to(device)
    target_gcn.fit(features, adj, labels, idx_train, idx_val, patience=30)
    # target_gcn.fit(features, adj, labels, idx_train)

    print('=== testing GCN on clean graph ===')
    test(adj, target_gcn)

    # Setup Attack Model
    print('=== setup attack model ===')
    model = PGDAttack(model=target_gcn, nnodes=adj.shape[0], loss_type='CE', device=device)
    model = model.to(device)

    # model.attack(features, adj, labels, idx_train, perturbations, epochs=args.epochs)
    # Here for the labels we need to replace it with predicted ones
    fake_labels = target_gcn.predict(features.to(device), adj.to(device))
    fake_labels = torch.argmax(fake_labels, 1).cpu()
    # Besides, we need to add the idx into the whole process
    idx_fake = np.concatenate([idx_train,idx_test])

    idx_others = list(set(np.arange(len(labels))) - set(idx_train))
    fake_labels = torch.cat([labels[idx_train], fake_labels[idx_others]])
    model.attack(features, adj, fake_labels, idx_fake, perturbations, epochs=args.epochs)

    print('=== testing GCN on Evasion attack ===')

    modified_adj = model.modified_adj
    test(modified_adj, target_gcn)

    print('=== testing GCN on Poisoning attack ===')
    test(modified_adj)
    print('-------------------')

    model.save_adj(root=f'/root', name=f'{args.dataset}_pgd_adj_{ptb_rate}')




if __name__ == '__main__':

    dataset = 'cora_ml'
    perturbation_rates = [0.05, 0.1, 0.15, 0.2, 0.25]

    for ptb_rate in perturbation_rates:
        parser.set_defaults(dataset=dataset)
        parser.set_defaults(ptb_rate=ptb_rate)
        args = parser.parse_args()
        main(1, ptb_rate, args)










