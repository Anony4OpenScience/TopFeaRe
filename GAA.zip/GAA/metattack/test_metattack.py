from deeprobust.graph.defense import GCN
from deeprobust.graph.global_attack import MetaApprox
from metattack import Metattack
from deeprobust.graph.utils import *
import argparse
from defense.load_datasets.dataset2 import Dataset
import os
os.environ['CUDA_LAUNCH_BLOCKING'] = '1'





parser = argparse.ArgumentParser()
parser.add_argument('--no-cuda', action='store_true', default=False,
                    help='Disables CUDA training.')
parser.add_argument('--seed', type=int, default=15, help='Random seed.')
parser.add_argument('--epochs', type=int, default=200,
                    help='Number of epochs to train.')
parser.add_argument('--lr', type=float, default=0.01,
                    help='Initial learning rate.')
parser.add_argument('--weight_decay', type=float, default=5e-4,
                    help='Weight decay (L2 loss on parameters).')
parser.add_argument('--hidden', type=int, default=16,
                    help='Number of hidden units.')
parser.add_argument('--dropout', type=float, default=0.05,
                    help='Dropout rate (1 - keep probability).')#cora_ml:.0.15
parser.add_argument('--dataset', type=str, default='pubmed',choices=['cora', 'cora_ml', 'citeseer', 'polblogs', 'aifb','email', 'mutag','pubmed'], help='dataset')
parser.add_argument('--ptb_rate', type=float, default=0, help='pertubation rate')# 0.2
parser.add_argument('--model', type=str, default='Meta-Self',
                    choices=['Meta-Self', 'A-Meta-Self', 'Meta-Train', 'A-Meta-Train'], help='model variant')

args = parser.parse_args()

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
# device = torch.device("cpu")

np.random.seed(args.seed)
torch.manual_seed(args.seed)
if device != 'cpu':
    torch.cuda.manual_seed(args.seed)

torch.cuda.empty_cache()

def main(n, ptb_rate, args):

    # data = Dataset(root='E:/Experiment/Code/defense/tmp/', name=args.dataset, setting='nettack')#metattack
    # data = Dataset(root='/tmp/pycharm_project_619/defense/tmp/', name=args.dataset, setting='nettack')#metattack
    data = Dataset(root=f'/root/', name=args.dataset, setting='prognn')  #metattack nettack
    adj, features, labels = data.adj, data.features, data.labels



    nnodes = adj.shape[0]
    print("数据集中的节点数量为:", nnodes)
    nedges = adj.sum() // 2
    nclass = labels.max().item() + 1
    nfeatures = features.shape[1]

    print("数据集中的节点数量为:", nnodes)
    print("数据集中的边数量为:", nedges)
    print("数据集中的类别数量为:", nclass)# 获取特征数量
    print("数据集中的特征数量为:", nfeatures)
    print(labels.min(), labels.max())



    print(len(labels))
    idx_train, idx_val, idx_test = data.idx_train, data.idx_val, data.idx_test
    idx_unlabeled = np.union1d(idx_val, idx_test)


    perturbations = int(args.ptb_rate * (adj.sum() // 2))
    adj, features, labels = preprocess(adj, features, labels, preprocess_adj=False)


    def test(adj):
        ''' test on GCN '''

        # adj = normalize_adj_tensor(adj)
        gcn = GCN(nfeat=features.shape[1],
                  nhid=args.hidden,
                  nclass=labels.max().item() + 1,
                  dropout=args.dropout, device=device)
        gcn = gcn.to(device)

        # if torch.cuda.device_count() > 1:
        #     gcn = nn.DataParallel(gcn)

        gcn.fit(features, adj, labels, idx_train)  # train without model picking
        # gcn.fit(features, adj, labels, idx_train, idx_val) # train with validation model picking
        output = gcn.output.cpu()

        loss_test = F.nll_loss(output[idx_test], labels[idx_test])
        acc_test = accuracy(output[idx_test], labels[idx_test])
        print("Test set results:",
              "loss= {:.4f}".format(loss_test.item()),
              "accuracy= {:.4f}".format(acc_test.item()))

        return acc_test.item()


    # 200 mod2   300 mod1  10 mod 100 mod4  400 mod3  450 mod5  150 mod6  50 mod7
    # 0.1 mod8 0.15 mod9 0.2 mod10 0.25 mod11 0.3 mod12
    # mod8 0.15/20  mod9 0.2/30 mod10 0.25/40 mod11 0.3/50 mod12 0.35/60 mod13 0.4/100
    # 50 100 150
    # 0.5 100
    # 0.1 100 150 200 250 300 350 400 450



    # Setup Surrogate Model
    surrogate = GCN(nfeat=features.shape[1], nclass=labels.max().item() + 1, nhid=16,
                    dropout=0.5, with_relu=False, with_bias=True, weight_decay=5e-4, device=device)

    surrogate = surrogate.to(device)

    surrogate.fit(features, adj, labels, idx_train)


    # Setup Attack Model
    if 'Self' in args.model:
        lambda_ = 0
    if 'Train' in args.model:
        lambda_ = 1
    if 'Both' in args.model:
        lambda_ = 0.5

    if 'A' in args.model:
        model = MetaApprox(model=surrogate, nnodes=adj.shape[0], feature_shape=features.shape, attack_structure=True,
                           attack_features=False, device=device, lambda_=lambda_)

    else:
        model = Metattack(model=surrogate, nnodes=adj.shape[0], feature_shape=features.shape, attack_structure=True,
                          attack_features=False, device=device, lambda_=lambda_)

    model = model.to(device)

    print(f"{args.dataset}_meta_adj_{ptb_rate}%")

    model.attack(features, adj, labels, idx_train, idx_unlabeled, n_perturbations=perturbations, ll_constraint=False)
    print('=== testing GCN on original(clean) graph ===')
    test(adj)
    modified_adj = model.modified_adj
    modified_features = model.modified_features


    test(modified_adj)

    model.save_adj(root=f'/root', name=f'{args.dataset}_meta_adj_{ptb_rate}')



if __name__ == '__main__':

    dataset = 'cora_ml'
    perturbation_rates = [0.05, 0.1, 0.15, 0.2, 0.25]

    for ptb_rate in perturbation_rates:
        parser.set_defaults(dataset=dataset)
        parser.set_defaults(ptb_rate=ptb_rate)
        args = parser.parse_args()
        main(1, ptb_rate, args)


