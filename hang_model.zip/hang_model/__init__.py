from .GNN_graphcon import GNN_graphcon
from .GNN_graphcon_time import GNN_graphcon_time